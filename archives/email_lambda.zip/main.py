def run(*args, **kwargs):
    print(f"Successfully executed lambda function with:")
    print(f"args={args}")
    print(f"kwargs={kwargs}")
